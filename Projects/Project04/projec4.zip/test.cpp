#include <iostream>
#include <string>
#include "hashTable.h"

using namespace std;

int main(){
  Node<string>* temp = new Node<string>;
  SLL<string>* tempSLL = new SLL<string>;
  HashTable<string>* tempT = new HashTable<string>(10007);
}
