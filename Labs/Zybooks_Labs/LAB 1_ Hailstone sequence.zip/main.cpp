#include <iostream>
using namespace std;

int main() {

   /* Type your code here. */

   return 0;
}
