// ItemToPurchase.h
#ifndef ITEM_TO_PURCHASE_H
#define ITEM_TO_PURCHASE_H

#include <string>
using namespace std;

class ItemToPurchase {
public:
    // Default constructor
    ItemToPurchase() {
        itemName = "none";
        itemPrice = 0;
        itemQuantity = 0;
    }

    // Accessors
    string GetName() const {
        return itemName;
    }

    int GetPrice() const {
        return itemPrice;
    }

    int GetQuantity() const {
        return itemQuantity;
    }

    // Mutators
    void SetName(const string& name) {
        itemName = name;
    }

    void SetPrice(int price) {
        itemPrice = price;
    }

    void SetQuantity(int quantity) {
        itemQuantity = quantity;
    }

private:
    string itemName;
    int itemPrice;
    int itemQuantity;
};

#endif
