#include <iostream>
#include <fstream>
using namespace std;

// quick sort function
void quickSort(int arr[], int left, int right) {

    // please implement this function
}

int main(int argc, char* argv[]){
  fstream input(argv[1]);

  int vals[5000];

    // please implement this function

}
